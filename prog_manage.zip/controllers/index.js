const user = require("./user");
const chat = require("./chat");

const controllers = {user,chat}

module.exports = controllers;