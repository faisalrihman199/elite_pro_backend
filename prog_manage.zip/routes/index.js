var express = require('express');
var router = express.Router();
var company = require('./company');
var chat = require('./chat')
const controllers = require("../controllers");

router.use('/chat',chat);
router.use('/company',company);
router.post('/login',controllers.user.login)


module.exports = router;
