var express = require('express');
var router = express.Router();
var controllers = require("../controllers");
var authmiddleware = require("../middleware/authmiddleware");
var upload = require("../middleware/filemiddleware");

router.post('/sendOtp', controllers.user.addCompany);
router.post('/verifyOtp', controllers.user.verifyOTP);
router.post('/sendEmpOtp', controllers.user.sendEmpOtp);
router.post('/verifyEmpOtp', controllers.user.verifyEmployeeOTP);
router.post('/addEmp',authmiddleware.authenticate('jwt', { session: false }),controllers.user.companyAddEmployee);
router.post('/createProject',authmiddleware.authenticate('jwt', { session: false }),upload.single('file'),controllers.user.addProjectForCompany);
router.post('/addEmpToProject',authmiddleware.authenticate('jwt', { session: false }),controllers.user.addOrUpdateProjectEmployee);
router.get('/getEmployees',authmiddleware.authenticate('jwt', { session: false }),controllers.user.getAllEmployeesForCompany);
router.get('/getProjects',authmiddleware.authenticate('jwt', { session: false }),controllers.user.getAllProjectsWithEmployees);
router.post("/createTask/:projectId",authmiddleware.authenticate('jwt', { session: false }),controllers.user.addTaskToProject);
router.post("/addEmpToTask",authmiddleware.authenticate('jwt', { session: false }),controllers.user.assignOrUpdateEmployeeToTask);
router.post("/addModule",authmiddleware.authenticate('jwt', { session: false }),controllers.user.addOrUpdateModuleForTask);
module.exports = router;
