const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");


const Employee = sequelize.define("employee", {
    full_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    designation:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    department:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    phone:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    address:{
        type: DataTypes.STRING,
        allowNull: false,
    },

})

module.exports = Employee;