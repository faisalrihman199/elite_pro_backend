const user = require("./user");
const employee = require("./employee");
const company = require("./company");
const tempUser = require("./tempUser");
const project = require("./project");
const projectEmployee = require("./projectEmployee");
const task = require("./task");
const employeeTask = require("./employeeTask");
const modules = require("./module");
const message = require("./message");
const conversation = require("./conversation");
const models = { user, employee, company ,tempUser,project,projectEmployee,project,projectEmployee,task,employeeTask,modules,message,conversation};

// Set up associations with cascading delete and update
user.hasMany(employee, {
  onDelete: "CASCADE", 
  onUpdate: "CASCADE", 
  foreignKey: "userId",
});
employee.belongsTo(user, {
  foreignKey: "userId",
});

user.hasMany(company, {
  onDelete: "CASCADE", 
  onUpdate: "CASCADE", 
  foreignKey: "userId",
});
company.belongsTo(user, {
  foreignKey: "userId",
});

company.hasMany(employee, {
  onDelete: "CASCADE", 
  onUpdate: "CASCADE", 
  foreignKey: "companyId",
});
employee.belongsTo(company, {
  foreignKey: "companyId",
});

company.hasMany(project, {
  onDelete: "CASCADE", 
  onUpdate: "CASCADE", 
  foreignKey: "companyId",
});
project.belongsTo(company, {
  foreignKey: "companyId",  
});

employee.belongsToMany(project, { 
    through: projectEmployee, 
    foreignKey: 'employeeId', 
    otherKey: 'projectId' 
  });
  
  project.belongsToMany(employee, { 
    through: projectEmployee, 
    foreignKey: 'projectId', 
    otherKey: 'employeeId' 
  });
  
  project.hasMany(task, {
    onDelete: "CASCADE", 
    onUpdate: "CASCADE", 
    foreignKey: "projectId",
  });
  
  task.belongsTo(project, {
    foreignKey: "projectId",
  });


  employee.belongsToMany(task, { 
    through: employeeTask, 
    foreignKey: 'employeeId', 
    otherKey: 'taskId' 
  });
  
  task.belongsToMany(employee, { 
    through: employeeTask, 
    foreignKey: 'taskId', 
    otherKey: 'employeeId' 
  });
  
  task.hasMany(modules, {
    onDelete: "CASCADE", 
    onUpdate: "CASCADE", 
    foreignKey: "taskId",
  });

  modules.belongsTo(task, {
    foreignKey: "projectId"
  })


  conversation.hasMany(message, {
    onDelete: "CASCADE", 
    onUpdate: "CASCADE", 
    foreignKey: "conversationId",
  });
  message.belongsTo(conversation, {
    foreignKey: "conversationId",
  });

  
module.exports = models;
